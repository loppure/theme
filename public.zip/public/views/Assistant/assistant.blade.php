<article>
  <header>
    <button class="close"></button>
    <div class="content-foto-assistant">
      <img src="#"/>
      <h6>Cerbero</h6>
    </div>
    <div class="help-assistant">
      <span>Novità</span>
      <a href="#">Cononoscimi</a>
    </div>
  </header>
  <div class="col-assistant content-categorie">
    <span>L'oppure ti racconta questo:</span>
    <ul>
      <!-- lista rubriche -->
    </ul>
  </div>
  <div class="col-assistant content-citta">
    <span>L'oppure si trova:</span>
    <ul>
      <!-- lista città -->
    </ul>
  </div>
  <div class="col-assistant content-last-article">
    <span>L'ultimo sguardo sul terrriotorio</span>
    <!-- contiene la card dell'ultimo articolo-->
  </div>
  <div class="col-assistant content-search">
    <span>I nostri progetti in atto</span>
    <!-- contiene la barra di ricerca -->
  </div>
  <footer>
    <!-- contiene la barra di ricerca -->
    <div class="content-search">
      <span>Se quello che ti ho proposto non basta cercalo qui</span>

    </div>
  </footer>
</article>
