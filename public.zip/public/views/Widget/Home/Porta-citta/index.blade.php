<div class="widget-image porta-citta">
  <img src="{{ get_template_directory_uri() }}/public/assets/src/img/icone-generiche/porta-loppure.svg" >
  <h3>Porta L'oppure nella tua città</h3>
  <div class="content-button">
    <a  href="{{ esc_url( home_url( '/' )) }}/rubriche/porta-loppure-nella-tua-citta" alt="" class="button">
      Portala
    </a>
  </div>
</div>
