<p>
    <label for="{{ $form['id'] }}">Title:</label>
    <input class="widefat" id="{{ $form['id'] }}" name="{{ $form['name'] }}" type="text" value="{{ $title }}">
</p>
