<div class="widget-action sostienici">
  <h3>Prendi un caffè insieme a noi</h3>
  <img src="#" title="icon-sostienici" />
  <div class="content-button">
    <a href="#" class="button">
      sostienici
    </a>
  </div>
</div>
