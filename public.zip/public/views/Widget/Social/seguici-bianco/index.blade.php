<div class="list-social-bianchi">
  <h3>Seguici</h3>
  <span>@LoppureIT</span>
  <ul>
    <li class="item-social">
      <a href="https://www.facebook.com/LoppureIT/" target="_blank" title="Seguici su Facebook">
        <img src=" {{ get_template_directory_uri() }}/public/assets/src/img/icone-social/facebook-bianco.svg" />
      </a>
    </li>
    <li class="item-social">
      <a href="https://twitter.com/loppureit" target="_blank" title="Seguici su Twitter">
        <img src="{{ get_template_directory_uri() }}/public/assets/src/img/icone-social/twitter-bianco.svg" />
      </a>
    </li>
    <li class="item-social">
      <a href="https://www.instagram.com/loppureit/" target="_blank" title="Seguici su Instagram">
        <img src="{{ get_template_directory_uri() }}/public/assets/src/img/icone-social/instagram-bianco.svg" />
      </a>
    </li>
    <li class="item-social">
      <a href="https://t.me/LoppureIT" target="_blank" title="Seguici su Telegram">
        <img src="{{ get_template_directory_uri() }}/public/assets/src/img/icone-social/telegram-bianco.svg" />
      </a>
    </li>
  </ul>
</div> <!-- .entry-social -->
