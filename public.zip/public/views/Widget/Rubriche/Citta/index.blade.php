<!-- Città -> Rubriche -->
<div class="widget-item citta">
  <h6>Scegli la città</h6>
  <ul>
    <li class="item citta-item pordenone">
      <a href="{{ esc_url( home_url( '/sezione' )) }}/pordenone" title="Carica gli articoli della città di Pordenone">
          Pordenone
      </a>
    </li>
    <li class="item citta-item udine">
      <a href="{{ esc_url( home_url( '/sezione' )) }}/udine" title="Carica gli articoli della città di Udine">
          Udine
      </a>
    </li>
    <li class="item citta-item trieste">
      <a href="{{ esc_url( home_url( '/sezione' )) }}/trieste" title="Carica gli articoli della città di Trieste">
          Trieste
      </a>
    </li>
    <li class="item citta-item gorizia">
      <a href="{{ esc_url( home_url( '/sezione' )) }}/gorizia" title="Carica gli articoli della città di Gorizia">
          Gorizia
      </a>
    </li>
  </ul>
  <ul>
    <li class="item citta-item treviso">
      <a href="{{ esc_url( home_url( '/sezione' )) }}/treviso" title="Carica gli articoli della città di Treviso">
          Treviso
      </a>
    </li>
  </ul>
    <!--TODO funzione che attiviamo appena implementiamo Overlay
    <div class="content-button-widget">
      <a class="button" href="" title="Carica tutti gli articoli delle città">
          Tutte
      </a>
    </div> -->
</div>
