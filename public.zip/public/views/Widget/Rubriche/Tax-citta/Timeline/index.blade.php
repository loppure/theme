<div class="widget-item timeline">
  <ul>
    <li class="item archive-item">
      <a href="#" title="Archivio per il mese di maggio">
          Adesso
      </a>
    </li>
    <li class="item archive-item">
      <a href="#" title="Archivio per il mese di giugno">
          Giugno
      </a>
    </li>
    <li class="item archive-item">
      <a href="#" title="Archivio per il mese di luglio">
          Luglio
      </a>
    </li>
    <li class="item archive-item">
      <a href="#" title="Archivio per il mese di agosto">
          Agosto
      </a>
    </li>
  </ul>
  <div class="content-button-widget">
    <a class="button" href="#" title="Pagina archivio">
      Archivio
    </a>
  </div>
</div>
