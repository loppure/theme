@extends('layout')

@section('content')
    <h1>FORBIDDEN!</h1>
@endsection('content')
