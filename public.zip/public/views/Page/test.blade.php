Test template for pages
