<section class="no-results not-found">
    <header class="page-header">
        <h1 class="page-title">Nessun post trovato</h1>
    </header><!-- .page-header -->

    <div class="page-content">
		    <p>Ci dispiace, ma qui non abbiamo nulla da mostrarti.</p>
    </div><!-- .page-content -->
</section><!-- .no-results -->
