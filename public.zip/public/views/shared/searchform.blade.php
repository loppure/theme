<form action="{{ bloginfo('url') }}" id="searchform" method="get">
	  <fieldset>
		    <label for="s" class="screen-reader-text">Search for:</label>
		    <input type="search" id="s" name="s" placeholder="Enter keywords" required />
		    <input type="submit" id="searchsubmit" value="Cerca" />
	  </fieldset>
</form>
