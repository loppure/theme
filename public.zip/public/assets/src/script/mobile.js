console.log("I suppouse you are a mobile!");

require('./desktop.js');
