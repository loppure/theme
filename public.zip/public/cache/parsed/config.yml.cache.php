<?php return array (
  'directory' => 
  array (
    'cache' => '/public/cache/',
    'assets' => '/public/assets/dist/',
    'views' => '/public/views/',
  ),
  'routing' => 
  array (
    'single' => '\\Loppure\\Controllers\\singleController',
    'taxonomy' => '\\Loppure\\Controllers\\taxController',
    'category' => '\\Loppure\\Controllers\\categoryController',
    'home' => '\\Loppure\\Controllers\\homeController',
    'author' => '\\Loppure\\Controllers\\authorController',
    'archive' => '\\Loppure\\Controllers\\archiveController',
    'search' => '\\Loppure\\Controllers\\searchController',
    'page' => '\\Loppure\\Controllers\\pageController',
    404 => '\\Loppure\\Controllers\\PageNotFoundController',
    'default' => '\\Loppure\\Controllers\\indexController',
  ),
  'custom_page_template' => 
  array (
    'esempio-1' => 'Primo esempio',
    'esempio-2' => 'Esempio 2',
  ),
); ?>